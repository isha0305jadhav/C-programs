/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdbool.h>
int main()
{
    unsigned int number;
    printf("enter a number:");
    scanf("%d",&number);
    bool lsb= (number&1);// or (number<<31)
    int result= sizeof(lsb);
    printf("\n size of lsb is: %d",result);
    if(lsb)
    {
        printf("\nlsb is set");
    }
    else
    {
        printf("\\nlsb s not set");
    }

    return 0;
}
