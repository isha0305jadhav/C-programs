/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int array[100], prime_numbers[100];
    int count = 0;
  
    // Fill the array from 1 to 100
    for (int i = 0; i < 100; i++) 
    {
        array[i] = i + 1;
    }
    printf ("numbers from 1 to 100:");
    for(int i=0;i<100;i++)
    {
        printf(" %d ",array[i]);
    }

    // Find prime numbers and store them in the 'primes' array
    for (int i = 0; i < 100; i++) 
    {
         int flag = 1;
        if (array[i] <= 1)
        {
            flag = 0;
        } 
        else 
        {
            for (int j = 2; j  <= array[i]/2; j++) 
            {
                if (array[i] % j == 0) 
                {
                    flag= 0;
                
                }
            }
        }

        if (flag)
        {
            prime_numbers[count] = array[i];
            count++;
        }
    }

    // Display the prime numbers
    printf(" \n Prime numbers between 1 to 100 are: \n");
    for (int i = 0; i < count; i++) 
    {
        printf(" %d ", prime_numbers[i]);
    }

    return 0;
}




