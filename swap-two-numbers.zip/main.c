/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int swap (int num1,int num2);
int exchange(int num1, int num2);
int interchange(int num1, int num2);

int swap(int num1,int num2)
{
    int temp;
    temp= num1;
    num1=num2;
    num2 =temp;
    printf("num1=%d num2=%d",num1,num2);
}
int exchange(int num1, int num2)
{
    num1= num1+num2;
    num2= num1-num2;
    num1= num1-num2;
    printf("num1=%d num2=%d", num1,num2);
}
int interchange(int num1, int num2)
{
    num1=num1^num2;
    num2=num1^num2;
    num1=num1^num2;
    printf("num1=%d num2=%d",num1,num2);
}
int main()
{
    int a,b;
    
    printf("Enter two numbers to be swap:");
    scanf("%d %d",&a,&b);
    printf("\n ********Using third variable result is********\n");
    swap(a,b);
    printf("\n ********Without using third variable result is********\n");
    exchange(a,b);
    printf("\n ********Using XOR operation result is********\n");
    interchange(a,b);
    

    return 0;
}
