/******************************************************************************
Name: Isha Jadhav
Program:- Use of dynamic memory allocation
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int *ptr;
    int n;

    printf("Enter number of elements: ");
    scanf("%d", &n);

  //dynamic memory allocation
    ptr = (int *)malloc(n * sizeof(int));
    // Storing values 
    for (int i = 0; i < n; i++) {
        ptr[i] = ((i + 1)*5);
    }
    // Print stored  values
    printf("Stored values: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", ptr[i]);
    }
    printf("\n");

    // Free the allocated memory
    free(ptr);

    return 0;
}

