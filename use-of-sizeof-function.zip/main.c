/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OChttps://www.onlinegdb.com/myfilesaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int array[10]={1,2,3,4,5,6,7,8,9,10};
    printf("\n size of array: %ld",sizeof(array));
    printf("\n number of bytes allocated to each element:%ld",sizeof(array[0]));
    printf("\n number of elements in array: %ld",sizeof(array)/sizeof(array[0]));

    return 0;
}
