/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int a[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int even[10], odd[10];
    int j = 0, k = 0;

    for (int i = 0; i < 10; i++) 
    {
        if (a[i] % 2 == 0) 
        {
            even[j] = a[i];
            j++;
        } 
        else 
        {
            odd[k] = a[i];
            k++;
        }
    }

    printf("\nEven numbers: ");
    for (int i = 0; i < j; i++) 
    {
        printf("%d ", even[i]);
    }

    printf("\nOdd numbers: ");
    for (int i = 0; i < k; i++) 
    {
        printf("%d ", odd[i]);
    }

    printf("\n");

    return 0;
}

