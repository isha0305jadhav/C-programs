/*Name: Isha Jadhav
  Program:- To reverse a string*/

#include <stdio.h>
#include <string.h>
//function to reverse a string
void reverse_string(char *s) {
    int l = 0;
    int r = strlen(s) - 1;
    char temp;

    while (l < r) {
        temp = s[l];
        s[l] = s[r];
        s[r] = temp;
        l++;
        r--;
    }
}

int main() {
    char word[100];
    printf("Enter a string: "); //take input from user
    fgets(word,100,stdin);
    for (int i = 0; word[i] != '\0'; i++) {
        if (word[i] == '\n') {
            word[i] = '\0';  
            break;           
        }
    }
    printf("\nEntered string is: %s\n", word);
    reverse_string(word);
    printf("Reversed string is: %s\n", word);

    return 0;
}
