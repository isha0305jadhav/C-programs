/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
// program that performs simple caculations:
#include <stdio.h>




int add(int a, int b)
{
   return a+b;
}
int sub(int a, int b)
{
    return a-b;
    
}
int mul(int a, int b)
{
    return a*b;
}
float division(int a, int b)
{
    if(b==0)
    {
        printf (" Second Opertor cannot be 0 ");
        return 0;
    }
    else
    {
         return (float)a/(float)b;
    }
   
}
int main()
{
    int a, b;
    char op;
    printf("\n Welcome to c calculator:");
    printf( "\n Enter two input number:");
    scanf("%d %d", &a, &b);
    printf(" \n Enter  the operator from '+' '-' '*' '/' : ");
    scanf(" %c", &op);
    
    switch (op) {
        case '+' : {
            printf("Result : %d",add(a,b));
            break;
            }
        case '-' : {
            printf("Result : %d",sub(a,b));
            break;
        }
        case '*' : {
            printf("Result : %d",mul(a,b));
            break;
        }
        case '/': {
            printf("Result : %.2f",division(a,b));
            break;
        }
        default: printf(" \n Please Enter valid operator:");
   
}
 return 0;
}
