#include <stdio.h>
int set_bit(int num,int pos);
int clear_bit(int num, int pos);
int toggle_bit (int num,int pos);
int check_bit (int num, int pos);
int result;
// set specific bit
int set_bit( int num, int pos) {
    return  num | (1 << pos);
}

// clear specific bit
int clear_bit(int num, int pos) {
    return num & ~(1 << pos);
}

// toggle specific bit
int toggle_bit(int num, int pos) {
    return num ^ (1 << pos);
}
//check specific bit
int check_bit(int num, int pos){
    return num & (1<<pos);
}

int main() {
    while(1){
    int num,pos;
    printf("enter a number and position of bit:");
    scanf("%d %d",&num,&pos);
    printf("Your Entered  number: %d\n", num);
    printf("After setting the %d bit: %d\n",pos,set_bit(num,pos));
    printf("enter a position to clear a bit:");
    scanf("%d",&pos);
    printf("Aftre clearing the %d bit: %d\n",pos,clear_bit(num,pos));
     printf("enter a position to toggle a bit:");
    scanf("%d",&pos);
    printf("Aftre toggling the %d bit: %d\n",pos,toggle_bit(num,pos));
    printf("enter a position to check a bit:");
    scanf("%d", &pos);
    printf("After checking bit at the %d position......\n",pos);
    result = check_bit(num,pos);
    if(result)
    {
       printf("The bit at position %d is set as 1\n", pos);

    }
    else
    {
         printf("The bit at position %d is not set as 0\n", pos);
    }
    
    
    }

    return 0;
}
