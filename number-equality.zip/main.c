/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int num1,num2;
    printf("Enter a two numbers to be check:");
    scanf("%d %d",&num1, &num2);
    if(num1^num2==0)
    {
        printf("numbers are equal.");
    }
    else{
        printf("numbers are not equal.");
    }
    return 0;
}