/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
#define MAX_LEN 50
void case_conversion(char *str);

void case_conversion(char *str)
{
    int len= strlen(str);
    for(int i=0;i<len;i++)
    {
        if(str[i]>='a'&&str[i]<='z')
        {
            str[i]=str[i]-32;
        }
        else if(str[i]>='A'&&str[i<='Z'])
        {
            str[i]=str[i]+32;
        }
    }
}

int main()
{
    char str[MAX_LEN];
    int len;
    printf("Enter a string: ");
    fgets(str, MAX_LEN, stdin);
    //gets(str);
    //scanf("%[^\n]",str);
    case_conversion(str);
    printf("\n After conversion: %s",str);

    return 0;
}
