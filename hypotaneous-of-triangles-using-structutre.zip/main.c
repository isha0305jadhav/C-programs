/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float result;
    struct triangle
    {
        float side1;
        float side2;
        float hypo;
    };
    struct triangle tri[3];
    
    for(int i=0;i<3;i++)
    {
        printf("\n Enter two sides of right angle triangle:");
       scanf("%f %f",&tri[i].side1,&tri[i].side2);
       result=(tri[i].side1*tri[i].side1)+(tri[i].side2*tri[i].side2);
       tri[i].hypo=result;
       printf("\n hypotaneous of given right angle triangle is %f",tri[i].hypo);
    }
       
        
    
   
    

    return 0;
}
