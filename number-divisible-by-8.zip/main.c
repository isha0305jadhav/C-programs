/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int divisible_by_8(int num);

int divisible_by_8(int num)
{
    if(num & 7==0)
    {
       return 1;
    }
    else{
       return 0;
    }
}
int main()
{
    int num;
    printf("Enter a number:");
    scanf("%d",&num);
    if(num==0){
        printf("zero divided by any number always result in 0");
    }
    else if((num%8==0) && (divisible_by_8(num)))
    {
        printf("\n Given number %d is divisible by 8",num);
    }
    else {
        printf("\n Given number %d is ot divisible by 8",num);
    }

    return 0;
}
