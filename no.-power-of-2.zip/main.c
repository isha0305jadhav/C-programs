#include <stdio.h>
int check(int num);
int power_of_2(int num);
int check(int num) {
    if (num <= 0) {
     return 0; 
    }
   else {
    while (num % 2 == 0) {
        num = num/2;
    }
    return num == 1;
   }
}
int power_of_2(int num){
    if(num <=0)
    {
        return 0;
    }
    else if(num>0){
        int result= num &(num-1);
        if(result==0)
        {
             return 1;
        }
        else{
            return 0;
        }
       
    }
}

int main() {
    int number;

    printf("Enter a number: ");
    scanf("%d", &number);

    
    if (check(number)) {
        printf("%d is a power of 2.\n", number);
    } else {
        printf("%d is not a power of 2.\n", number);
    }
    if (power_of_2(number)) {
        printf("%d is a power of 2.\n", number);
    } else {
        printf("%d is not a power of 2.\n", number);
    }

    return 0;
}
