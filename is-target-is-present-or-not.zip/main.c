/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int array[5]= {5,7,12,20,25};
int target;
int main()
{
    printf("Enter your Target:");
    scanf("%d",&target);
    for(int i=0;i<=5;i++)
    {
        if(array[i]==target)
        {
            printf("position of your target is:%d",i);
        }
    }

    return 0;
}