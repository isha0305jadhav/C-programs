#include <stdio.h>

 unsigned char reverseBits( char num) {
    int num_bits = sizeof(num) * 8;  
    unsigned char reversed_num = 0;
    
    for (int i = 0; i < num_bits; i++) {
        
        if (num & (1 << i)) {
            reversed_num =reversed_num | (1 << ((num_bits - 1) - i));
        }
    }
    
    return reversed_num;
}

int main() {
     unsigned int number;
     printf("enter a number in the range of 0 to 255:");
     scanf("%d",&number);
     if(number<0||number>255)
     {
         printf("Invalid number. Please enter a number in the given range");
     }
     else{
         unsigned char num = (unsigned char)number;
         unsigned char reversed = reverseBits(num);
         printf("Original number: %d\n", num);
         printf("Reversed bits number: %d\n", reversed);
     }
    return 0;
}
