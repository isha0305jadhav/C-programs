/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.
code to check the given two strings are anagram of ach other using string function.
*******************************************************************************/
#include <stdio.h>
#include <string.h>  //able to use string functions 
#include <stdbool.h> //returs value eighter 'true' or 'false'

// Function to sort a string
void sortString(char* str) {
    int len = strlen(str);
    for (int i = 0; i < len - 1; i++) {
        for (int j = i + 1; j < len; j++) {
            if (str[i] > str[j]) {
                char temp = str[i];
                str[i] = str[j];
                str[j] = temp;
            }
        }
    }
}

// Function to check if two strings are anagrams
bool areAnagrams(char* str1, char* str2) {
    if (strlen(str1) != strlen(str2)) {
        return false; // If lengths differ, they can't be anagrams
    }

    sortString(str1); // Sort the first string
    sortString(str2); // Sort the second string

    return strcmp(str1, str2) == 0; // Compare sorted strings
}

int main() {
    char str1[100], str2[100];

    printf("Enter first string: ");
    scanf("%s", str1);
    printf("Enter second string: ");
    scanf("%s", str2);

    if (areAnagrams(str1, str2)) {
        printf("The strings are anagrams.\n");
    } else {
        printf("The strings are not anagrams.\n");
    }

    return 0;
}
