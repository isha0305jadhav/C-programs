/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int num;
    printf("Enter an integer:");
    scanf("%d",&num);
    if(num==0){
        printf("%d is not an even nor a odd number.",num);
    }
    else {
        if(num%2==0){
            printf("%d is an even number.",num);
        }
        else {
            printf("%d is odd number.",num);
        }
    }

    return 0;
}