/******************************************************************************
Name:- Isha Jadhav
Program:- Basic understanding of link list
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
//define element of linklist in structure
struct node{
    int value;
    struct node *next;
};
typedef struct node node_t;
//function to print a list
void printlist(node_t*head)
{
    node_t *temp=head;
    while(temp!=NULL){
        printf(" %d ",temp->value);
        temp=temp->next;
    }
    printf("\n");
}
int main()
{
    node_t n1,n2,n3; // 3 elements in linklist
    node_t *head;
    n1.value=8;
    n2.value=58;
    n3.value=5;
    //link elements in the linklist with whatever order you want
    head=&n2;
    n2.next=&n1;
    n1.next=&n3;
    n3.next=NULL;
    printlist(head);
    return 0;
}